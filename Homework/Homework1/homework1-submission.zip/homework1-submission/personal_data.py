#!/usr/bin/env python
#
# personal_data.py
#
myKey = "AIzaSyC5ul7VOqqW6VdeaP6_3LEqGIjEOTu1f2U"
mySearchId = "006861748815945794285:a6wav_lykku"
